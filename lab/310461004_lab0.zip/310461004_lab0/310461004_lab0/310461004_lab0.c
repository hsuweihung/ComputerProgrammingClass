#include <stdio.h>
int main()
{
    char s[100] = {'\0'};

    scanf("%s", s);

    printf("Hello NYCU CS\n%s\n", s);

    return 0;
}